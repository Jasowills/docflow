/**
 * Shared types for the RouteCTRL Recorder extension.
 * Mirrors a subset of @routectrl/shared models for standalone use.
 */
export {};
//# sourceMappingURL=types.js.map